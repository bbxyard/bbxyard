const Promise = require('bluebird');

module.exports.up = () => Promise.resolve();

module.exports.down = () => Promise.resolve();
